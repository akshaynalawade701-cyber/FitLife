# FitLife — Fitness Website

A fast, responsive static site with calculators, a workout plan builder, and a nutrition tracker. All data stays local in your browser.

## Features
- BMI, BMR, TDEE calculators (metric/imperial)
- Workout builder (goal, experience, days/week, equipment) with save/print
- Nutrition tracker with goals, daily meals, progress bars, import/export (JSON)
- Classes, pricing, trainers, testimonials, FAQ, and contact form
- Light/dark theme toggle; mobile-friendly navigation
- Privacy and terms pages

## Run locally
From the project root:

```bash
cd /workspace/fitness-website
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Tech
- HTML, CSS, JavaScript (no frameworks)
- LocalStorage for persistence; no backend required

## License
MIT